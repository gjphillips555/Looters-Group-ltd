"use client"

import { useState } from "react"
import { ExternalLink, ShoppingCart, Check, MapPin, Truck } from "lucide-react"
import { useCart, nzd, type ShippingOption } from "@/components/cart-provider"

export type Product = {
  id: string
  title: string
  categoryPath: string | null
  priceLabel: string
  amount: number
  buyNow: boolean
  photo: string | null
  region: string | null
  listingUrl: string
  isNew: boolean
  shipping: ShippingOption[]
  maxQty: number
}

export function ProductCard({ product }: { product: Product }) {
  const { add, isInCart } = useCart()
  const [added, setAdded] = useState(false)
  const canBuy = product.buyNow && product.amount > 0
  const inCart = isInCart(product.id)
  // TradeMe lists a single unit unless it states otherwise.
  const singleOnly = product.maxQty <= 1
  const alreadyMaxed = inCart && singleOnly

  function handleAdd() {
    add({
      id: product.id,
      title: product.title,
      amount: product.amount,
      priceLabel: product.priceLabel,
      photo: product.photo,
      shipping: product.shipping,
      maxQty: product.maxQty,
    })
    setAdded(true)
    window.setTimeout(() => setAdded(false), 1200)
  }

  return (
    <article className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card transition-colors hover:border-primary/50">
      <div className="relative aspect-square overflow-hidden bg-secondary/40">
        {product.photo ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={product.photo || "/placeholder.svg"}
            alt={product.title}
            crossOrigin="anonymous"
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className="grid h-full place-items-center text-sm text-muted-foreground">
            No photo
          </div>
        )}
        {product.isNew && (
          <span className="absolute left-3 top-3 rounded-full bg-accent px-2.5 py-1 text-xs font-semibold text-accent-foreground">
            New
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-3 p-4">
        {product.categoryPath && (
          <p className="truncate text-xs uppercase tracking-wide text-muted-foreground">
            {product.categoryPath.split("/").filter(Boolean).slice(-1)[0]}
          </p>
        )}
        <h3 className="line-clamp-2 text-pretty font-sans text-sm font-medium leading-snug">
          {product.title}
        </h3>

        {product.region && (
          <p className="flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="size-3" /> {product.region}
          </p>
        )}

        {canBuy && product.shipping.length > 0 && (
          <div className="rounded-lg border border-border/70 bg-secondary/30 p-2.5">
            <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
              <Truck className="size-3.5" /> Shipping options
            </p>
            <ul className="space-y-1">
              {product.shipping.map((s) => (
                <li
                  key={s.id}
                  className="flex items-center justify-between gap-2 text-xs"
                >
                  <span className="min-w-0 truncate text-muted-foreground">
                    {s.label}
                  </span>
                  <span className="shrink-0 font-medium tabular-nums text-foreground">
                    {s.price > 0 ? nzd(s.price) : "Free"}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="mt-auto flex items-end justify-between gap-2 pt-2">
          <div>
            <p className="font-display text-lg font-bold text-accent">
              {product.priceLabel}
            </p>
            <p className="text-[11px] text-muted-foreground">
              {product.buyNow
                ? singleOnly
                  ? "Buy Now · 1 available"
                  : `Buy Now · up to ${product.maxQty}`
                : "Auction"}
            </p>
          </div>

          {canBuy ? (
            <button
              type="button"
              onClick={handleAdd}
              disabled={alreadyMaxed}
              className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {added || alreadyMaxed ? (
                <Check className="size-4" />
              ) : (
                <ShoppingCart className="size-4" />
              )}
              {alreadyMaxed ? "In cart" : added ? "Added" : "Add"}
            </button>
          ) : (
            <a
              href={product.listingUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 rounded-md border border-border px-3 py-2 text-sm font-medium transition-colors hover:bg-secondary"
            >
              View <ExternalLink className="size-3.5" />
            </a>
          )}
        </div>
      </div>
    </article>
  )
}
