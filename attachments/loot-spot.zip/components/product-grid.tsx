"use client"

import useSWR from "swr"
import { AlertCircle, Loader2 } from "lucide-react"
import { ProductCard, type Product } from "@/components/product-card"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export function ProductGrid() {
  const { data, error, isLoading } = useSWR<{ products: Product[]; error?: string }>(
    "/api/listings",
    fetcher,
    { revalidateOnFocus: false },
  )

  if (isLoading) {
    return (
      <div className="flex items-center justify-center gap-2 py-24 text-muted-foreground">
        <Loader2 className="size-5 animate-spin" />
        <span>Loading live listings…</span>
      </div>
    )
  }

  if (error || data?.error) {
    return (
      <div className="mx-auto flex max-w-md flex-col items-center gap-2 py-24 text-center text-muted-foreground">
        <AlertCircle className="size-8 text-destructive" />
        <p className="font-medium text-foreground">Couldn&apos;t load listings</p>
        <p className="text-sm">
          The TradeMe catalog is temporarily unavailable. Please try again shortly.
        </p>
      </div>
    )
  }

  const products = data?.products ?? []

  if (products.length === 0) {
    return (
      <div className="py-24 text-center text-muted-foreground">
        No live listings right now — check back soon.
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  )
}
