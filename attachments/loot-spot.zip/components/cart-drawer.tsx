"use client"

import { X, Trash2, ShoppingBag, Truck } from "lucide-react"
import { useCart, nzd } from "@/components/cart-provider"
import { QuantityStepper } from "@/components/quantity-stepper"

// GST is inclusive in NZ TradeMe prices; shown as a derived breakdown only.
const GST_RATE = 0.15

export function CartDrawer({
  open,
  onClose,
}: {
  open: boolean
  onClose: () => void
}) {
  const {
    lines,
    subtotal,
    shippingTotal,
    total,
    itemCount,
    setQty,
    setShipping,
    remove,
    clear,
  } = useCart()
  const gstPortion = total - total / (1 + GST_RATE)

  return (
    <>
      <div
        aria-hidden={!open}
        onClick={onClose}
        className={`fixed inset-0 z-40 bg-black/60 transition-opacity ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      />
      <aside
        role="dialog"
        aria-label="Shopping cart"
        aria-modal="true"
        className={`fixed right-0 top-0 z-50 flex h-dvh w-full max-w-md flex-col border-l border-border bg-card shadow-2xl transition-transform duration-300 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <header className="flex items-center justify-between border-b border-border px-5 py-4">
          <h2 className="flex items-center gap-2 font-display text-lg font-semibold">
            <ShoppingBag className="size-5 text-primary" />
            Your Cart
            <span className="text-sm font-normal text-muted-foreground">
              ({itemCount})
            </span>
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close cart"
            className="grid size-9 place-items-center rounded-md text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
          >
            <X className="size-5" />
          </button>
        </header>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {lines.length === 0 ? (
            <div className="grid h-full place-items-center text-center">
              <div className="space-y-2">
                <ShoppingBag className="mx-auto size-10 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Your cart is empty. Add some Buy Now finds.
                </p>
              </div>
            </div>
          ) : (
            <ul className="space-y-5">
              {lines.map((line) => {
                const selectedShip = line.shipping.find(
                  (s) => s.id === line.shippingId,
                )
                return (
                  <li key={line.id} className="flex flex-col gap-3">
                    <div className="flex gap-3">
                      <div className="size-16 shrink-0 overflow-hidden rounded-md bg-secondary/40">
                        {line.photo ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={line.photo || "/placeholder.svg"}
                            alt={line.title}
                            crossOrigin="anonymous"
                            className="h-full w-full object-cover"
                          />
                        ) : null}
                      </div>
                      <div className="flex min-w-0 flex-1 flex-col gap-1.5">
                        <p className="line-clamp-2 text-sm font-medium leading-snug">
                          {line.title}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {nzd(line.amount)} each
                        </p>
                        <div className="mt-auto flex items-center justify-between">
                          <QuantityStepper
                            size="sm"
                            value={line.qty}
                            max={line.maxQty}
                            onChange={(q) => setQty(line.id, q)}
                          />
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold tabular-nums">
                              {nzd(line.amount * line.qty)}
                            </span>
                            <button
                              type="button"
                              onClick={() => remove(line.id)}
                              aria-label={`Remove ${line.title}`}
                              className="grid size-7 place-items-center rounded-md text-muted-foreground transition-colors hover:bg-destructive/15 hover:text-destructive"
                            >
                              <Trash2 className="size-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Shipping options pulled verbatim from TradeMe. */}
                    <div className="rounded-lg border border-border/70 bg-secondary/30 p-2.5">
                      <label
                        htmlFor={`ship-${line.id}`}
                        className="mb-1.5 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground"
                      >
                        <Truck className="size-3.5" /> Shipping
                      </label>
                      <select
                        id={`ship-${line.id}`}
                        value={line.shippingId}
                        onChange={(e) => setShipping(line.id, e.target.value)}
                        className="w-full rounded-md border border-border bg-background px-2.5 py-2 text-xs text-foreground outline-none focus:border-primary"
                      >
                        {line.shipping.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.label} — {s.price > 0 ? nzd(s.price) : "Free"}
                          </option>
                        ))}
                      </select>
                      {selectedShip && selectedShip.price > 0 && (
                        <p className="mt-1.5 text-right text-xs text-muted-foreground">
                          + {nzd(selectedShip.price)} shipping
                        </p>
                      )}
                    </div>
                  </li>
                )
              })}
            </ul>
          )}
        </div>

        {lines.length > 0 && (
          <footer className="space-y-4 border-t border-border px-5 py-4">
            <dl className="space-y-1.5 text-sm">
              <div className="flex justify-between text-muted-foreground">
                <dt>Items</dt>
                <dd className="tabular-nums">{nzd(subtotal)}</dd>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <dt>Shipping</dt>
                <dd className="tabular-nums">
                  {shippingTotal > 0 ? nzd(shippingTotal) : "Free"}
                </dd>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <dt>GST (15% incl.)</dt>
                <dd className="tabular-nums">{nzd(gstPortion)}</dd>
              </div>
              <div className="flex justify-between border-t border-border pt-1.5 text-base font-semibold">
                <dt>Total</dt>
                <dd className="tabular-nums text-accent">{nzd(total)}</dd>
              </div>
            </dl>
            <p className="text-[11px] leading-relaxed text-muted-foreground">
              Prices and shipping are pulled live from TradeMe and shown exactly
              as listed. Totals are calculated on your device.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={clear}
                className="rounded-md border border-border px-4 py-2.5 text-sm font-medium transition-colors hover:bg-secondary"
              >
                Clear
              </button>
              <button
                type="button"
                className="flex-1 rounded-md bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
              >
                Checkout · {nzd(total)}
              </button>
            </div>
          </footer>
        )}
      </aside>
    </>
  )
}
