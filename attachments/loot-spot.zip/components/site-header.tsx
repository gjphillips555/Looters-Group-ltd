"use client"

import { useState } from "react"
import { ShoppingCart } from "lucide-react"
import { useCart } from "@/components/cart-provider"
import { CartDrawer } from "@/components/cart-drawer"

export function SiteHeader() {
  const [open, setOpen] = useState(false)
  const { itemCount } = useCart()

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/85 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <a href="/" className="flex items-center gap-3" aria-label="LootersRetail home">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/looters-logo.png"
            alt="LootersRetail"
            className="h-11 w-auto sm:h-12"
          />
          <span className="sr-only">LootersRetail — live TradeMe deals</span>
        </a>

        <button
          type="button"
          onClick={() => setOpen(true)}
          className="relative inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm font-medium transition-colors hover:bg-secondary"
        >
          <ShoppingCart className="size-4" />
          <span className="hidden sm:inline">Cart</span>
          {itemCount > 0 && (
            <span className="absolute -right-2 -top-2 grid min-w-5 place-items-center rounded-full bg-accent px-1 text-xs font-bold text-accent-foreground">
              {itemCount}
            </span>
          )}
        </button>
      </div>

      <CartDrawer open={open} onClose={() => setOpen(false)} />
    </header>
  )
}
