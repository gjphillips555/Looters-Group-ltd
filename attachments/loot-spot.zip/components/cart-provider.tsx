"use client"

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react"

export type ShippingOption = {
  id: string
  label: string
  price: number
}

export type CartProduct = {
  id: string
  title: string
  amount: number
  priceLabel: string
  photo: string | null
  shipping: ShippingOption[]
  maxQty: number
}

export type CartLine = CartProduct & { qty: number; shippingId: string }

type CartContextValue = {
  lines: CartLine[]
  itemCount: number
  subtotal: number
  shippingTotal: number
  total: number
  add: (product: CartProduct) => void
  setQty: (id: string, qty: number) => void
  setShipping: (id: string, shippingId: string) => void
  remove: (id: string) => void
  clear: () => void
  isInCart: (id: string) => boolean
}

const CartContext = createContext<CartContextValue | null>(null)

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([])

  const add = useCallback((product: CartProduct) => {
    setLines((prev) => {
      const existing = prev.find((l) => l.id === product.id)
      const cap = Math.max(1, product.maxQty)
      if (existing) {
        // Respect the quantity TradeMe actually allows for this listing.
        return prev.map((l) =>
          l.id === product.id ? { ...l, qty: Math.min(cap, l.qty + 1) } : l,
        )
      }
      const shippingId = product.shipping[0]?.id ?? ""
      return [...prev, { ...product, qty: 1, shippingId }]
    })
  }, [])

  const setQty = useCallback((id: string, qty: number) => {
    setLines((prev) => {
      const line = prev.find((l) => l.id === id)
      if (!line) return prev
      const cap = Math.max(1, line.maxQty)
      const clamped = Math.max(0, Math.min(cap, Math.round(qty)))
      if (clamped === 0) return prev.filter((l) => l.id !== id)
      return prev.map((l) => (l.id === id ? { ...l, qty: clamped } : l))
    })
  }, [])

  const setShipping = useCallback((id: string, shippingId: string) => {
    setLines((prev) =>
      prev.map((l) => (l.id === id ? { ...l, shippingId } : l)),
    )
  }, [])

  const remove = useCallback((id: string) => {
    setLines((prev) => prev.filter((l) => l.id !== id))
  }, [])

  const clear = useCallback(() => setLines([]), [])

  const isInCart = useCallback(
    (id: string) => lines.some((l) => l.id === id),
    [lines],
  )

  const { itemCount, subtotal, shippingTotal } = useMemo(() => {
    return lines.reduce(
      (acc, l) => {
        const ship = l.shipping.find((s) => s.id === l.shippingId)
        acc.itemCount += l.qty
        acc.subtotal += l.qty * l.amount
        // Shipping is charged once per listing, mirroring TradeMe checkout.
        acc.shippingTotal += ship?.price ?? 0
        return acc
      },
      { itemCount: 0, subtotal: 0, shippingTotal: 0 },
    )
  }, [lines])

  const total = subtotal + shippingTotal

  const value = useMemo(
    () => ({
      lines,
      itemCount,
      subtotal,
      shippingTotal,
      total,
      add,
      setQty,
      setShipping,
      remove,
      clear,
      isInCart,
    }),
    [
      lines,
      itemCount,
      subtotal,
      shippingTotal,
      total,
      add,
      setQty,
      setShipping,
      remove,
      clear,
      isInCart,
    ],
  )

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

export function useCart() {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error("useCart must be used within a CartProvider")
  return ctx
}

export const nzd = (amount: number) =>
  new Intl.NumberFormat("en-NZ", { style: "currency", currency: "NZD" }).format(amount)
