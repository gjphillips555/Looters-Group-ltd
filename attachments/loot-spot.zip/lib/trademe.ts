import "server-only"

// LootersRetail TradeMe seller member id (read-only source of truth).
export const MEMBER_ID = "9233545"

const API_BASE = "https://api.trademe.co.nz/v1"

export type ShippingOption = {
  id: string
  label: string
  // Amount in NZD, taken verbatim from TradeMe. 0 = free / pickup.
  price: number
}

export type Product = {
  id: string
  title: string
  categoryPath: string | null
  priceLabel: string
  // Amount in NZD used purely for cart math on our side. TradeMe data is never mutated.
  amount: number
  buyNow: boolean
  photo: string | null
  region: string | null
  listingUrl: string
  isNew: boolean
  // Shipping options exactly as listed on TradeMe (typically 2 per listing).
  shipping: ShippingOption[]
  // How many units the customer may buy. 1 unless TradeMe lists more.
  maxQty: number
}

type TradeMeListing = {
  ListingId: number
  Title: string
  Category?: string
  CategoryPath?: string
  StartPrice?: number
  BuyNowPrice?: number
  PriceDisplay?: string
  PhotoUrls?: string[]
  PictureHref?: string
  Region?: string
  IsNew?: boolean
}

type TradeMeShippingOption = {
  Type?: string
  Price?: number
  Method?: string
  ShippingId?: number
}

type TradeMeListingDetail = TradeMeListing & {
  ShippingOptions?: TradeMeShippingOption[]
  Quantity?: number
  MaximumBuyNowQuantity?: number
  IsBuyNowOnly?: boolean
  Photos?: { Value?: { FullSize?: string; Large?: string; Gallery?: string } }[]
}

type TradeMeSearchResponse = {
  TotalCount?: number
  List?: TradeMeListing[]
}

/**
 * TradeMe supports OAuth 1.0a PLAINTEXT for application-only (public data)
 * requests. The signature is simply `consumerSecret&` (no token secret).
 */
function authHeader(): string {
  const key = process.env.TRADEME_CONSUMER_KEY
  const secret = process.env.TRADEME_CONSUMER_SECRET
  if (!key || !secret) {
    throw new Error("Missing TRADEME_CONSUMER_KEY or TRADEME_CONSUMER_SECRET")
  }
  return [
    'OAuth oauth_consumer_key="' + key + '"',
    'oauth_signature_method="PLAINTEXT"',
    'oauth_signature="' + secret + '&"',
  ].join(", ")
}

// Best-resolution photo TradeMe exposes for a listing.
function bestPhoto(detail: TradeMeListingDetail, fallback: TradeMeListing): string | null {
  const fromPhotos = detail.Photos?.[0]?.Value
  const hi = fromPhotos?.FullSize || fromPhotos?.Large || fromPhotos?.Gallery
  if (hi) return hi
  return (fallback.PhotoUrls && fallback.PhotoUrls[0]) || fallback.PictureHref || null
}

function mapShipping(options: TradeMeShippingOption[] | undefined): ShippingOption[] {
  if (!options || options.length === 0) {
    return [{ id: "tbc", label: "Shipping arranged after purchase", price: 0 }]
  }
  return options.map((o, i) => {
    const price = typeof o.Price === "number" ? o.Price : 0
    let label = o.Method?.trim() || ""
    if (!label) {
      switch (o.Type) {
        case "Free":
          label = "Free shipping"
          break
        case "Pickup":
          label = "Pickup"
          break
        case "Custom":
          label = "Courier / post"
          break
        default:
          label = "Shipping"
      }
    }
    if (o.Type === "Free" || price === 0) {
      if (o.Type === "Pickup" && !/pickup/i.test(label)) label = `${label} (pickup)`
    }
    return { id: String(o.ShippingId ?? o.Type ?? i), label, price }
  })
}

async function fetchDetail(id: number): Promise<TradeMeListingDetail | null> {
  try {
    const res = await fetch(`${API_BASE}/Listings/${id}.json`, {
      headers: { Authorization: authHeader(), Accept: "application/json" },
      next: { revalidate: 60 },
    })
    if (!res.ok) return null
    return (await res.json()) as TradeMeListingDetail
  } catch {
    return null
  }
}

async function normalize(listing: TradeMeListing): Promise<Product> {
  const detail = await fetchDetail(listing.ListingId)
  const merged: TradeMeListingDetail = { ...listing, ...(detail ?? {}) }

  const buyNow = typeof merged.BuyNowPrice === "number" && merged.BuyNowPrice > 0
  const amount = buyNow ? (merged.BuyNowPrice as number) : (merged.StartPrice ?? 0)
  const priceLabel =
    merged.PriceDisplay ??
    (amount > 0
      ? new Intl.NumberFormat("en-NZ", { style: "currency", currency: "NZD" }).format(amount)
      : "Price on request")

  const listedQty =
    (typeof merged.MaximumBuyNowQuantity === "number" && merged.MaximumBuyNowQuantity) ||
    (typeof merged.Quantity === "number" && merged.Quantity) ||
    1
  const maxQty = buyNow ? Math.max(1, Math.min(99, listedQty)) : 1

  return {
    id: String(listing.ListingId),
    title: merged.Title,
    categoryPath: merged.CategoryPath ?? merged.Category ?? null,
    priceLabel,
    amount,
    buyNow,
    photo: bestPhoto(merged, listing),
    region: merged.Region ?? null,
    listingUrl: `https://www.trademe.co.nz/a/marketplace/listing/${listing.ListingId}`,
    isNew: Boolean(merged.IsNew),
    shipping: mapShipping(merged.ShippingOptions),
    maxQty,
  }
}

export async function getMemberListings(): Promise<Product[]> {
  const url = `${API_BASE}/Search/General.json?member_listing=${MEMBER_ID}&rows=100&sort_order=Default`

  const res = await fetch(url, {
    headers: {
      Authorization: authHeader(),
      Accept: "application/json",
    },
    // Cache the read-only catalog briefly; TradeMe data itself is untouched.
    next: { revalidate: 60 },
  })

  if (!res.ok) {
    const body = await res.text().catch(() => "")
    throw new Error(`TradeMe API ${res.status}: ${body.slice(0, 200)}`)
  }

  const data = (await res.json()) as TradeMeSearchResponse
  const list = data.List ?? []
  return Promise.all(list.map(normalize))
}
