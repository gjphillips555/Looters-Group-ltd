import { NextResponse } from "next/server"
import { getMemberListings } from "@/lib/trademe"

export async function GET() {
  try {
    const products = await getMemberListings()
    return NextResponse.json({ products })
  } catch (error) {
    console.log("[v0] listings route error:", (error as Error).message)
    return NextResponse.json(
      { products: [], error: "Unable to load listings right now." },
      { status: 502 },
    )
  }
}
