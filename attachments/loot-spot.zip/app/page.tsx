import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { ProductGrid } from "@/components/product-grid"

export default function HomePage() {
  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:px-6">
        <section className="mb-8 flex flex-col gap-3 rounded-2xl border border-border bg-card px-6 py-8 sm:px-8">
          <span className="w-fit rounded-full bg-primary/15 px-3 py-1 text-xs font-semibold text-primary">
            Live from TradeMe
          </span>
          <h1 className="text-balance font-display text-3xl font-bold tracking-tight sm:text-4xl">
            Loot the best deals, straight from our TradeMe store
          </h1>
          <p className="max-w-2xl text-pretty text-sm leading-relaxed text-muted-foreground sm:text-base">
            Every item below is pulled live from the LootersRetail TradeMe
            listings. Add Buy Now finds to your cart, adjust quantities, and we&apos;ll
            tally your total in NZD — all without touching a thing on TradeMe.
          </p>
        </section>

        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-xl font-semibold">Current listings</h2>
        </div>

        <ProductGrid />
      </main>

      <SiteFooter />
    </div>
  )
}
